#include "gba.h"

void playSound(int idkTheArgs) {
	UNUSED(idkTheArgs);
}