/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 NoteImage NoteImage.png 
 * Time-stamp: Monday 11/19/2018, 13:46:18
 * 
 * Image Information
 * -----------------
 * NoteImage.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef NOTEIMAGE_H
#define NOTEIMAGE_H

extern const unsigned short NoteImage[400];
#define NOTEIMAGE_SIZE 800
#define NOTEIMAGE_LENGTH 400
#define NOTEIMAGE_WIDTH 20
#define NOTEIMAGE_HEIGHT 20

#endif

