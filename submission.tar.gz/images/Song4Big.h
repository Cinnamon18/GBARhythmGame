/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 Song4Big Song4Big.png 
 * Time-stamp: Monday 11/19/2018, 15:22:30
 * 
 * Image Information
 * -----------------
 * Song4Big.png 80@80
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SONG4BIG_H
#define SONG4BIG_H

extern const unsigned short Song4Big[6400];
#define SONG4BIG_SIZE 12800
#define SONG4BIG_LENGTH 6400
#define SONG4BIG_WIDTH 80
#define SONG4BIG_HEIGHT 80

#endif

