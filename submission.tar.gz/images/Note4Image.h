/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 Note4Image Note4Image.png 
 * Time-stamp: Monday 11/19/2018, 16:03:50
 * 
 * Image Information
 * -----------------
 * Note4Image.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef NOTE4IMAGE_H
#define NOTE4IMAGE_H

extern const unsigned short Note4Image[400];
#define NOTE4IMAGE_SIZE 800
#define NOTE4IMAGE_LENGTH 400
#define NOTE4IMAGE_WIDTH 20
#define NOTE4IMAGE_HEIGHT 20

#endif

