/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 SongSelectScreen SongSelectScreen.png 
 * Time-stamp: Monday 11/19/2018, 12:44:17
 * 
 * Image Information
 * -----------------
 * SongSelectScreen.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SONGSELECTSCREEN_H
#define SONGSELECTSCREEN_H

extern const unsigned short SongSelectScreen[38400];
#define SONGSELECTSCREEN_SIZE 76800
#define SONGSELECTSCREEN_LENGTH 38400
#define SONGSELECTSCREEN_WIDTH 240
#define SONGSELECTSCREEN_HEIGHT 160

#endif

