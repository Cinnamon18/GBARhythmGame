/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 VictoryScreen VictoryScreen.png 
 * Time-stamp: Monday 11/19/2018, 12:47:36
 * 
 * Image Information
 * -----------------
 * VictoryScreen.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef VICTORYSCREEN_H
#define VICTORYSCREEN_H

extern const unsigned short VictoryScreen[38400];
#define VICTORYSCREEN_SIZE 76800
#define VICTORYSCREEN_LENGTH 38400
#define VICTORYSCREEN_WIDTH 240
#define VICTORYSCREEN_HEIGHT 160

#endif

