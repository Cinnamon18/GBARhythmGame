/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 Note3Image Note3Image.png 
 * Time-stamp: Monday 11/19/2018, 15:32:12
 * 
 * Image Information
 * -----------------
 * Note3Image.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef NOTE3IMAGE_H
#define NOTE3IMAGE_H

extern const unsigned short Note3Image[400];
#define NOTE3IMAGE_SIZE 800
#define NOTE3IMAGE_LENGTH 400
#define NOTE3IMAGE_WIDTH 20
#define NOTE3IMAGE_HEIGHT 20

#endif

