/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 Note2Image Note2Image.png 
 * Time-stamp: Monday 11/19/2018, 15:21:50
 * 
 * Image Information
 * -----------------
 * Note2Image.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef NOTE2IMAGE_H
#define NOTE2IMAGE_H

extern const unsigned short Note2Image[400];
#define NOTE2IMAGE_SIZE 800
#define NOTE2IMAGE_LENGTH 400
#define NOTE2IMAGE_WIDTH 20
#define NOTE2IMAGE_HEIGHT 20

#endif

