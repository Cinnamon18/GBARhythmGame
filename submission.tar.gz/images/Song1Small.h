/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 Song1Small Song1Small.png 
 * Time-stamp: Monday 11/19/2018, 15:22:43
 * 
 * Image Information
 * -----------------
 * Song1Small.png 50@50
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SONG1SMALL_H
#define SONG1SMALL_H

extern const unsigned short Song1Small[2500];
#define SONG1SMALL_SIZE 5000
#define SONG1SMALL_LENGTH 2500
#define SONG1SMALL_WIDTH 50
#define SONG1SMALL_HEIGHT 50

#endif

