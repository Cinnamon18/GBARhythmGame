/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 Song1Big Song1Big.png 
 * Time-stamp: Monday 11/19/2018, 15:22:12
 * 
 * Image Information
 * -----------------
 * Song1Big.png 80@80
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SONG1BIG_H
#define SONG1BIG_H

extern const unsigned short Song1Big[6400];
#define SONG1BIG_SIZE 12800
#define SONG1BIG_LENGTH 6400
#define SONG1BIG_WIDTH 80
#define SONG1BIG_HEIGHT 80

#endif

