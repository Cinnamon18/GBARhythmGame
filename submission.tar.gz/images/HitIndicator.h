/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 HitIndicator HitIndicator.png 
 * Time-stamp: Monday 11/19/2018, 12:46:52
 * 
 * Image Information
 * -----------------
 * HitIndicator.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef HITINDICATOR_H
#define HITINDICATOR_H

extern const unsigned short HitIndicator[400];
#define HITINDICATOR_SIZE 800
#define HITINDICATOR_LENGTH 400
#define HITINDICATOR_WIDTH 20
#define HITINDICATOR_HEIGHT 20

#endif

