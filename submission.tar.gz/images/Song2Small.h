/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 Song2Small Song2Small.png 
 * Time-stamp: Monday 11/19/2018, 15:22:49
 * 
 * Image Information
 * -----------------
 * Song2Small.png 50@50
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SONG2SMALL_H
#define SONG2SMALL_H

extern const unsigned short Song2Small[2500];
#define SONG2SMALL_SIZE 5000
#define SONG2SMALL_LENGTH 2500
#define SONG2SMALL_WIDTH 50
#define SONG2SMALL_HEIGHT 50

#endif

