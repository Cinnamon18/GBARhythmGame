/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 SplashScreen SplashScreen.png 
 * Time-stamp: Monday 11/19/2018, 12:47:24
 * 
 * Image Information
 * -----------------
 * SplashScreen.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SPLASHSCREEN_H
#define SPLASHSCREEN_H

extern const unsigned short SplashScreen[38400];
#define SPLASHSCREEN_SIZE 76800
#define SPLASHSCREEN_LENGTH 38400
#define SPLASHSCREEN_WIDTH 240
#define SPLASHSCREEN_HEIGHT 160

#endif

