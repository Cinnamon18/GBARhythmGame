/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 Song2Big Song2Big.png 
 * Time-stamp: Monday 11/19/2018, 15:22:21
 * 
 * Image Information
 * -----------------
 * Song2Big.png 80@80
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SONG2BIG_H
#define SONG2BIG_H

extern const unsigned short Song2Big[6400];
#define SONG2BIG_SIZE 12800
#define SONG2BIG_LENGTH 6400
#define SONG2BIG_WIDTH 80
#define SONG2BIG_HEIGHT 80

#endif

