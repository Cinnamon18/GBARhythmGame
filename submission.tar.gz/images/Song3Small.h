/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 Song3Small Song3Small.png 
 * Time-stamp: Monday 11/19/2018, 15:22:53
 * 
 * Image Information
 * -----------------
 * Song3Small.png 50@50
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SONG3SMALL_H
#define SONG3SMALL_H

extern const unsigned short Song3Small[2500];
#define SONG3SMALL_SIZE 5000
#define SONG3SMALL_LENGTH 2500
#define SONG3SMALL_WIDTH 50
#define SONG3SMALL_HEIGHT 50

#endif

