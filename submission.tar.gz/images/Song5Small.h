/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 Song5Small Song5Small.png 
 * Time-stamp: Monday 11/19/2018, 15:23:13
 * 
 * Image Information
 * -----------------
 * Song5Small.png 50@50
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SONG5SMALL_H
#define SONG5SMALL_H

extern const unsigned short Song5Small[2500];
#define SONG5SMALL_SIZE 5000
#define SONG5SMALL_LENGTH 2500
#define SONG5SMALL_WIDTH 50
#define SONG5SMALL_HEIGHT 50

#endif

