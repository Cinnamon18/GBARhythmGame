/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 Song5Big Song5Big.png 
 * Time-stamp: Monday 11/19/2018, 15:22:35
 * 
 * Image Information
 * -----------------
 * Song5Big.png 80@80
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SONG5BIG_H
#define SONG5BIG_H

extern const unsigned short Song5Big[6400];
#define SONG5BIG_SIZE 12800
#define SONG5BIG_LENGTH 6400
#define SONG5BIG_WIDTH 80
#define SONG5BIG_HEIGHT 80

#endif

