/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 RhythmBackground RhythmBackground.png 
 * Time-stamp: Monday 11/19/2018, 12:46:23
 * 
 * Image Information
 * -----------------
 * RhythmBackground.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef RHYTHMBACKGROUND_H
#define RHYTHMBACKGROUND_H

extern const unsigned short RhythmBackground[38400];
#define RHYTHMBACKGROUND_SIZE 76800
#define RHYTHMBACKGROUND_LENGTH 38400
#define RHYTHMBACKGROUND_WIDTH 240
#define RHYTHMBACKGROUND_HEIGHT 160

#endif

