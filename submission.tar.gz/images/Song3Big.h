/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 Song3Big Song3Big.png 
 * Time-stamp: Monday 11/19/2018, 15:22:25
 * 
 * Image Information
 * -----------------
 * Song3Big.png 80@80
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SONG3BIG_H
#define SONG3BIG_H

extern const unsigned short Song3Big[6400];
#define SONG3BIG_SIZE 12800
#define SONG3BIG_LENGTH 6400
#define SONG3BIG_WIDTH 80
#define SONG3BIG_HEIGHT 80

#endif

