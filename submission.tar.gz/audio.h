#ifndef AUDIO_SEEN
#define AUDIO_SEEN

#include "gba.h"

void playSound(int idkTheArgs);

#endif
