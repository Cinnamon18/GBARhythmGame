#ifndef BEATMAPS_SEEN
#define BEATMAPS_SEEN

extern const unsigned short map1[13];
#define MAP1_SIZE 13

extern const unsigned short map2[10];
#define MAP2_SIZE 10

extern const unsigned short map3[31];
#define MAP3_SIZE 31

extern const unsigned short map4[40];
#define MAP4_SIZE 40

extern const unsigned short map5[33];
#define MAP5_SIZE 33


#endif
